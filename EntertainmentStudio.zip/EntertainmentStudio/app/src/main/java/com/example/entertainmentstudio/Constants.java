package com.example.entertainmentstudio;

public class Constants {

    // Base URL for API
    public static final String DB_NAME = "news_table";
}
